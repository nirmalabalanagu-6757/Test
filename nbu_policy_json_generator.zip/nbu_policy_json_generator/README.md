# NetBackup Policy JSON Generator

## Files

- `generate_nbu_policy_json.py` - main script
- `policy_input.csv` - policy input
- `base_schedule_template.json` - policy JSON whose complete `schedules` array is copied
- `source_json\` - place downloaded existing-policy JSON files here
- `generated_json\` - generated PROD and VAL JSON files
- `reports\` - execution report

## Required preparation

1. Place the downloaded source policy JSON in:

   `source_json\z_test_sai.json`

2. Place the common schedule template JSON in:

   `base_schedule_template.json`

3. Update `policy_input.csv`.

## CSV columns

Required:

- `Policyname`
- `Prod_policy_name`
- `val_policy_name`
- `Policy_type`
- `Master_Server_Name`

Optional:

- `fullbackup_time`
- `inc_time`

These two time columns are currently informational because the script replaces the
entire schedule array from `base_schedule_template.json`.

Optional VMware selection columns:

- `prod_vm_name`
- `val_vm_name`

You can supply one VM name:

`fre0-viaas-8149`

Or multiple VM names separated by semicolons:

`vm01;vm02;vm03`

You can also provide a complete NetBackup VMware query.

When the selection columns are empty or absent, the original source-policy
backup selections remain unchanged in the generated JSON.

## Run

Windows:

```powershell
python generate_nbu_policy_json.py
```

The script creates JSON only. It does not create policies on the NetBackup server.
