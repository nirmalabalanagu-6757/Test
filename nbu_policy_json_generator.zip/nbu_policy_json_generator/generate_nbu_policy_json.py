#!/usr/bin/env python3
"""
Generate two new NetBackup policy JSON files from one existing policy JSON.

For every CSV row:
1. Read the existing policy JSON.
2. Read schedules from one common base-template JSON.
3. Create PROD and VAL copies.
4. Replace policy names.
5. Replace the complete schedules array in both copies.
6. Optionally replace VMware backup selections.
7. Save both generated JSON files.

This script only creates JSON files. It does not call the NetBackup API.
"""

import copy
import csv
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


###############################################################################
# CONFIGURATION
###############################################################################

BASE_DIR = Path(__file__).resolve().parent

INPUT_CSV = BASE_DIR / "policy_input.csv"
SOURCE_JSON_DIR = BASE_DIR / "source_json"
BASE_TEMPLATE_JSON = BASE_DIR / "base_schedule_template.json"
OUTPUT_DIR = BASE_DIR / "generated_json"
REPORT_DIR = BASE_DIR / "reports"

# When True, an output policy is rejected if Policy_type in CSV does not match
# the policyType found in the source JSON.
VALIDATE_POLICY_TYPE = True


###############################################################################
# HELPERS
###############################################################################

def normalize_header(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def clean_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def safe_filename(value: str) -> str:
    value = re.sub(r'[\\/:*?"<>|]+', "_", value.strip())
    return value or "unnamed_policy"


def load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"JSON file not found: {path}")

    with path.open("r", encoding="utf-8-sig") as handle:
        data = json.load(handle)

    if not isinstance(data, dict):
        raise ValueError(f"Top-level JSON must be an object: {path}")

    return data


def get_policy_object(document: Dict[str, Any]) -> Dict[str, Any]:
    """
    Supports the downloaded NetBackup wrapper:

        data -> attributes -> policy

    It also supports a JSON file containing the policy object directly.
    """
    try:
        policy = document["data"]["attributes"]["policy"]
        if not isinstance(policy, dict):
            raise TypeError
        return policy
    except (KeyError, TypeError):
        pass

    if "policyName" in document and isinstance(document, dict):
        return document

    raise KeyError(
        "Policy object not found. Expected "
        "data.attributes.policy or a direct policy object."
    )


def update_response_wrapper(document: Dict[str, Any], new_policy_name: str) -> None:
    """
    Update response-wrapper values when they exist.
    These fields are not created if they are absent.
    """
    data = document.get("data")
    if not isinstance(data, dict):
        return

    if "id" in data:
        data["id"] = new_policy_name

    links = data.get("links")
    if isinstance(links, dict):
        self_link = links.get("self")
        if isinstance(self_link, dict) and "href" in self_link:
            self_link["href"] = f"/config/policies/{new_policy_name}"

    meta = data.get("meta")
    if isinstance(meta, dict) and "accessControlId" in meta:
        policy = get_policy_object(document)
        policy_type = clean_text(policy.get("policyType", "VMware")).upper()
        meta["accessControlId"] = (
            f"|PROTECTION|POLICIES|{policy_type}|{new_policy_name}|"
        )


def vm_selection_from_name(vm_name: str) -> str:
    escaped_name = vm_name.replace("'", r"\'")
    return f"vmware:/?filter=Displayname Equal '{escaped_name}'"


def parse_selection_value(value: str) -> Optional[List[str]]:
    """
    Accepted optional CSV values:

    1. A full NetBackup VMware query:
       vmware:/?filter=Displayname Equal 'server01'

    2. One VM name:
       server01

    3. Multiple VM names separated by semicolon:
       server01;server02;server03

    4. Multiple complete queries separated by semicolon.
    """
    value = clean_text(value)
    if not value:
        return None

    items = [item.strip() for item in value.split(";") if item.strip()]
    selections: List[str] = []

    for item in items:
        if item.lower().startswith("vmware:/"):
            selections.append(item)
        else:
            selections.append(vm_selection_from_name(item))

    return selections or None


def find_source_json(policy_name: str) -> Path:
    """
    First tries <Policyname>.json.
    If not found, performs a case-insensitive filename match.
    """
    exact_path = SOURCE_JSON_DIR / f"{policy_name}.json"
    if exact_path.exists():
        return exact_path

    wanted = f"{policy_name}.json".lower()
    for candidate in SOURCE_JSON_DIR.glob("*.json"):
        if candidate.name.lower() == wanted:
            return candidate

    raise FileNotFoundError(
        f"Source JSON for policy '{policy_name}' was not found under "
        f"{SOURCE_JSON_DIR}"
    )


def build_new_policy(
    source_document: Dict[str, Any],
    template_schedules: List[Dict[str, Any]],
    new_policy_name: str,
    new_selections: Optional[List[str]],
) -> Dict[str, Any]:
    new_document = copy.deepcopy(source_document)
    policy = get_policy_object(new_document)

    policy["policyName"] = new_policy_name
    policy["schedules"] = copy.deepcopy(template_schedules)

    if new_selections is not None:
        backup_selections = policy.setdefault("backupSelections", {})
        if not isinstance(backup_selections, dict):
            raise ValueError(
                f"backupSelections is not an object in policy {new_policy_name}"
            )
        backup_selections["selections"] = new_selections

    update_response_wrapper(new_document, new_policy_name)
    return new_document


def save_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=4, ensure_ascii=False)
        handle.write("\n")


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"Input CSV not found: {path}")

    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)

        if not reader.fieldnames:
            raise ValueError("CSV header is missing.")

        rows: List[Dict[str, str]] = []
        for original in reader:
            normalized = {
                normalize_header(key): clean_text(value)
                for key, value in original.items()
                if key is not None
            }
            rows.append(normalized)

    return rows


def first_value(row: Dict[str, str], *names: str) -> str:
    for name in names:
        value = row.get(normalize_header(name), "")
        if value:
            return value
    return ""


###############################################################################
# MAIN
###############################################################################

def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    SOURCE_JSON_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 72)
    print("NETBACKUP POLICY JSON GENERATOR")
    print("=" * 72)

    try:
        template_document = load_json(BASE_TEMPLATE_JSON)
        template_policy = get_policy_object(template_document)
        template_schedules = template_policy.get("schedules")

        if not isinstance(template_schedules, list) or not template_schedules:
            raise ValueError(
                "No schedules found in base_schedule_template.json at "
                "data.attributes.policy.schedules"
            )

        rows = read_csv_rows(INPUT_CSV)

    except Exception as exc:
        print(f"Initialization failed: {exc}")
        return 1

    if not rows:
        print("No data rows found in policy_input.csv")
        return 1

    report_rows: List[Dict[str, str]] = []

    for row_number, row in enumerate(rows, start=2):
        source_policy_name = first_value(
            row, "Policyname", "policy_name", "source_policy_name"
        )
        prod_policy_name = first_value(
            row, "Prod_policy_name", "prod_policy_name"
        )
        val_policy_name = first_value(
            row, "val_policy_name", "validation_policy_name"
        )
        csv_policy_type = first_value(
            row, "Policy_type", "policy_type"
        )
        master_server = first_value(
            row, "Master_Server_Name", "master_server_name"
        )

        # Optional columns. If absent, original backup selections are retained.
        prod_selection_value = first_value(
            row,
            "prod_vm_name",
            "prod_vm_names",
            "prod_selection",
            "prod_backup_selection",
        )
        val_selection_value = first_value(
            row,
            "val_vm_name",
            "val_vm_names",
            "val_selection",
            "val_backup_selection",
        )

        entry = {
            "row_number": str(row_number),
            "source_policy": source_policy_name,
            "prod_policy": prod_policy_name,
            "val_policy": val_policy_name,
            "policy_type": csv_policy_type,
            "master_server": master_server,
            "prod_json": "",
            "val_json": "",
            "status": "FAILED",
            "message": "",
        }

        try:
            if not source_policy_name:
                raise ValueError("Policyname is empty.")
            if not prod_policy_name:
                raise ValueError("Prod_policy_name is empty.")
            if not val_policy_name:
                raise ValueError("val_policy_name is empty.")
            if prod_policy_name.lower() == val_policy_name.lower():
                raise ValueError(
                    "Prod_policy_name and val_policy_name must be different."
                )

            source_path = find_source_json(source_policy_name)
            source_document = load_json(source_path)
            source_policy = get_policy_object(source_document)

            source_policy_type = clean_text(source_policy.get("policyType"))

            if (
                VALIDATE_POLICY_TYPE
                and csv_policy_type
                and source_policy_type
                and csv_policy_type.lower() != source_policy_type.lower()
            ):
                raise ValueError(
                    f"CSV Policy_type '{csv_policy_type}' does not match "
                    f"source JSON policyType '{source_policy_type}'."
                )

            prod_selections = parse_selection_value(prod_selection_value)
            val_selections = parse_selection_value(val_selection_value)

            prod_document = build_new_policy(
                source_document=source_document,
                template_schedules=template_schedules,
                new_policy_name=prod_policy_name,
                new_selections=prod_selections,
            )

            val_document = build_new_policy(
                source_document=source_document,
                template_schedules=template_schedules,
                new_policy_name=val_policy_name,
                new_selections=val_selections,
            )

            prod_path = OUTPUT_DIR / f"{safe_filename(prod_policy_name)}.json"
            val_path = OUTPUT_DIR / f"{safe_filename(val_policy_name)}.json"

            save_json(prod_path, prod_document)
            save_json(val_path, val_document)

            entry["prod_json"] = str(prod_path)
            entry["val_json"] = str(val_path)
            entry["status"] = "SUCCESS"

            if prod_selections is None or val_selections is None:
                entry["message"] = (
                    "JSON files created. Missing optional PROD/VAL selection "
                    "columns were left unchanged from the source policy."
                )
            else:
                entry["message"] = (
                    "JSON files created with common template schedules and "
                    "separate PROD/VAL VMware selections."
                )

            print(
                f"[SUCCESS] {source_policy_name} -> "
                f"{prod_policy_name}, {val_policy_name}"
            )

        except Exception as exc:
            entry["message"] = str(exc)
            print(f"[FAILED] Row {row_number}: {exc}")

        report_rows.append(entry)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = REPORT_DIR / f"policy_generation_report_{timestamp}.csv"

    fieldnames = [
        "row_number",
        "source_policy",
        "prod_policy",
        "val_policy",
        "policy_type",
        "master_server",
        "prod_json",
        "val_json",
        "status",
        "message",
    ]

    with report_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(report_rows)

    success_count = sum(1 for row in report_rows if row["status"] == "SUCCESS")
    failed_count = len(report_rows) - success_count

    print("=" * 72)
    print(f"Successful rows : {success_count}")
    print(f"Failed rows     : {failed_count}")
    print(f"Generated JSON  : {OUTPUT_DIR}")
    print(f"Report          : {report_path}")
    print("=" * 72)

    return 0 if failed_count == 0 else 2


if __name__ == "__main__":
    sys.exit(main())
